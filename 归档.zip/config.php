<?php
/**
 * 数据库配置文件（MySQL 专用）
 */

return [
    'type'  => 'mysql',
    'mysql' => [
        'host'     => 'localhost',
        'port'     => 8889,
        'dbname'   => 'root',
        'username' => 'root',
        'password' => 'root',
        'charset'  => 'utf8mb4',
    ],
];
